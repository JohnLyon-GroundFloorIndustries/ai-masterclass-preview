"""Reproducible stdlib-only static build. Run from any directory."""
import base64
import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from course import MODULES, PHASES

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'release'
OUT.mkdir(exist_ok=True)
TITLE='Ground_Floor_Academy_AI_Masterclass_Beginner_Edition.html'
def make_zip(destination,files):
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path,name in sorted(files,key=lambda x:x[1]):
            info=zipfile.ZipInfo(name,date_time=(2026,10,31,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,path.read_bytes())
def included(path):
    return path.is_file() and not any(p in {'__pycache__','outputs','.git','.venv'} for p in path.parts) and path.suffix not in {'.pyc','.db'}
labzip=OUT/'Ground_Floor_Academy_Engineering_Labs.zip'
make_zip(labzip,[(p,str(p.relative_to(ROOT/'labs')).replace('\\','/')) for p in (ROOT/'labs').rglob('*') if included(p)])
curriculum=['# Curriculum and learning path — Beginner v1.0','',
'Audience: adults who can use a computer and have asked ChatGPT questions. No programming knowledge assumed.',
'',f'{len(MODULES)} modules, 51 lessons, six phases. Suggested workload: {sum(m["hours"] for m in MODULES)} hours, including practice. At 5 hours/week allow approximately 34 weeks; pace is a planning estimate, not a promise.',
'','Weekly rhythm: two 60-minute reading/simulation sessions, one 2-hour real exercise, one hour of retrieval practice and troubleshooting. Pause to reproduce a result before advancing. Allow extra time for capstone changes and independent review.',
'','All lessons contain outcome, relevance, plain explanation, bounded analogy, technical explanation, clickable visual, steps, practice, expected output, troubleshooting, explanatory check, ability recap and a connection forward.',
'','Prerequisite chain: each lesson builds on the preceding lesson; Module 0 starts from the stated audience knowledge. Modules 0–2 need only a browser. Module 3 introduces terminal and Python setup before code execution. Modules 4–6 introduce agents/tools/retrieval before frameworks. Infrastructure follows real local programs; production topics follow deployment and reliability.',
'','Completion, correct concept checks, attempted exercises, successful educational simulations and learner-supplied executable evidence are recorded separately. No professional qualification is implied.']
for pi,phase in enumerate(PHASES):
    curriculum += ['',f'## Phase {pi+1}: {phase}']
    for mi,m in enumerate(MODULES):
        if m['phase']!=pi: continue
        curriculum += ['',f'### Module {mi}: {m["title"]} — {m["hours"]} hours',f'Prerequisite: {"basic computer use" if mi==0 else "Modules 0–"+str(mi-1)}.',f'Project: {m["project"]}']
        for li,l in enumerate(m['lessons']):
            curriculum += [f'- {mi}.{li+1} {l["title"]}: {l["outcome"]}',f'  Practice: {l["practice"]}',f'  Success indicator: {l["expected"]}']
curriculum += ['','## Practical review rubric','For each of the 14 capstone gates: 0 absent; 1 explained; 2 executed with reproducible evidence; 3 independently reproduced and challenged. Do not add points for opening lessons. Submit source, tests, evaluation, architecture, access controls, approval evidence, recovery, measured load and runbooks. Live model/cloud/container work remains separately verified.']
curriculum='\n'.join(curriculum)+'\n'
(OUT/'Curriculum_and_Learning_Path.md').write_text(curriculum,encoding='utf-8')
setup=(ROOT/'labs/SETUP.md').read_text(encoding='utf-8')
(OUT/'Student_Getting_Started_Guide.md').write_text(setup,encoding='utf-8')
qa=(ROOT/'QA.md').read_text(encoding='utf-8')
(OUT/'Quality_Assurance_Report.md').write_text(qa,encoding='utf-8')
sources=[
 ['Official GFI logo artwork and palette','https://johnlyon-groundfloorindustries.github.io/LogoPack/'],
 ['Earlier advanced course (preserved separately)','https://johnlyon-groundfloorindustries.github.io/ai-masterclass-preview/'],
 ['Python: Windows setup','https://docs.python.org/3/using/windows.html'],
 ['Python: macOS setup','https://docs.python.org/3/using/mac.html'],
 ['Python tutorial','https://docs.python.org/3/tutorial/'],
 ['OpenAI: tool use','https://developers.openai.com/api/docs/guides/tools'],
 ['OpenAI: evaluation best practices','https://developers.openai.com/api/docs/guides/evaluation-best-practices'],
 ['MCP architecture','https://modelcontextprotocol.io/docs/learn/architecture'],
 ['LangGraph overview','https://docs.langchain.com/oss/python/langgraph/overview'],
 ['OpenAI Agents SDK','https://openai.github.io/openai-agents-python/'],
 ['CrewAI introduction','https://docs.crewai.com/en/introduction'],
 ['AutoGen documentation','https://microsoft.github.io/autogen/stable/'],
 ['Docker container concepts','https://docs.docker.com/get-started/docker-concepts/the-basics/what-is-a-container/'],
 ['Kubernetes overview','https://kubernetes.io/docs/concepts/overview/'],
 ['GitHub Pages documentation','https://docs.github.com/en/pages'],
 ['WCAG 2.2','https://www.w3.org/TR/WCAG22/']]
import sys
sys.path.insert(0,str(ROOT/'labs'))
from tools import DOCUMENTS
data=dict(modules=MODULES,phases=PHASES,glossary=json.loads((ROOT/'glossary.json').read_text(encoding='utf-8')),hello=(ROOT/'labs/hello.py').read_text(encoding='utf-8'),setup=setup,labReadme=(ROOT/'labs/README.md').read_text(encoding='utf-8'),deployment=(ROOT/'labs/DEPLOYMENT.md').read_text(encoding='utf-8'),labZip=base64.b64encode(labzip.read_bytes()).decode(),curriculum=curriculum,qa=qa,sources=sources,documents=DOCUMENTS)
logo=ROOT/'assets/gfi-horizontal-for-light-bg.svg'
html=(ROOT/'template.html').read_text(encoding='utf-8').replace('/*STYLE*/',(ROOT/'style.css').read_text(encoding='utf-8')).replace('/*LOGO*/','data:image/svg+xml;base64,'+base64.b64encode(logo.read_bytes()).decode()).replace('/*DATA*/',json.dumps(data,ensure_ascii=False).replace('<','\\u003c')).replace('/*APP*/',(ROOT/'app.js').read_text(encoding='utf-8'))
(OUT/TITLE).write_text(html,encoding='utf-8')
(OUT/'index.html').write_text(html,encoding='utf-8')
(OUT/'.nojekyll').write_text('',encoding='utf-8')
(OUT/'Source_Ledger.md').write_text('# Source ledger\n\nOriginal instructional prose and fictional examples. Official sources checked October 31, 2026; links are optional references, not offline dependencies.\n\n'+'\n'.join(f'- [{title}]({url})' for title,url in sources)+'\n\nAdvanced reference commit: eb3141c72a26db5184cc3113d0a5f9a79da36f03\nLogoPack commit: e5a8ea42ebfed75fbfd0418203e17d1c2d79068f\n',encoding='utf-8')
make_zip(OUT/'Developer_Source.zip',[(p,'source/'+str(p.relative_to(ROOT)).replace('\\','/')) for p in ROOT.rglob('*') if included(p)])
hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS.json'}
(OUT/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
print(f'Built {len(MODULES)} modules / 51 lessons; HTML {len(html.encode()):,} bytes; lab ZIP {labzip.stat().st_size:,} bytes')
