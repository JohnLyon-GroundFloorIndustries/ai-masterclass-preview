# Beginner Edition developer source

Requirements: Python 3.10+ standard library. No build packages or network access required.

From the folder containing this `source` folder run:

```text
python source/build.py
```

On macOS/Linux use `python3`. The script creates the sibling `release` folder with the named offline HTML, `index.html` for GitHub Pages, embedded/downloadable lab ZIP, guides, QA report, source archive and hashes. ZIP entry dates are fixed for reproducible content. Authored curriculum is in `course.py`; interface in `template.html`, `style.css`, `app.js`; glossary in JSON; runnable code and complete setup in `labs/`. The official logo is stored in `assets/` and embedded without redrawing.

Run lab checks from `source/labs` using `python run_evidence.py`. Generated output is excluded from release archives. QA scripts may require locally installed test tooling; the shipped course and core lab do not.

Run `node source/quality/unit.cjs` from the folder containing `source` after building to repeat JavaScript/static checks (Node.js required only for this developer check). Saved browser and lab evidence is in `source/quality/`. Browser checks used the available browser tool; axe-core was a QA dependency only, not a learning-app dependency.

Publish only the generated release files under a new `beginner-v1/` directory in the course repository. Preserve root files and existing branches; check the current branch head before committing. The UI is static; GitHub Pages does not host its Python backend.

Security properties: user inputs are rendered with textContent or HTML escaping; imports accept only known fields and IDs; no untrusted code evaluation; no external runtime requests; progress key isolated from earlier courses. The progress/evidence files are learner-controlled and not signed assessment records.
