# Deployment and rollback practice

## Native local deployment — required first

From the extracted lab folder run `python server.py` (`python3` on macOS/Linux). Open `http://127.0.0.1:8765/` in your browser. Submit the default question. Expect a JSON result with `status: awaiting_review`, an access-policy source and researcher/drafter/reviewer events. Open `/health`; expect `status: ok`. Stop with Ctrl+C. This is a working local deployment; it is not a cloud deployment.

## Git walkthrough

Install Git from [git-scm.com](https://git-scm.com/downloads) using your OS installer, then reopen the terminal and verify `git --version`. A repository stores version history. Run these commands in a **copy** of the lab folder:

```text
git init
git status
git add .
git diff --cached
git commit -m "Initial tested training service"
git log --oneline -1
```

`init` creates history storage; `status` lists changes; `add` stages files; `diff --cached` lets you review exactly what will be recorded; `commit` saves a snapshot; `log` shows its identifier. If Git asks for identity, configure your intended name and email for this repository using `git config user.name "Your Name"` and `git config user.email "your intended address"`. Do not copy invented identity values. `.gitignore` excludes outputs, databases and environment files. Review anyway before committing. GitHub hosting is optional; pushing publishes to the repository's audience, so inspect what you are sharing.

## Optional Docker — not required for offline learning

Install Docker using the official [Docker installation instructions](https://docs.docker.com/get-started/get-docker/) for your OS and review its license/system requirements. Open Docker Desktop where applicable; wait for its engine. Verify `docker version` shows a working server, not only a client. Then, in the lab folder:

```text
docker build -t gfa-lab:v1 .
docker run --rm --name gfa-lab -p 127.0.0.1:8765:8765 gfa-lab:v1
```

`build` packages the Dockerfile; `-t` names the image; `.` supplies this folder. `run` starts it. `--rm` removes the stopped container, not your source. The mapping exposes only the host loopback interface. Open the same local URL and health path. Ctrl+C stops the foreground container. If the port is busy, stop your earlier native server first. A first build needs network access to obtain the base image. Record the resolved image digest for reproducibility; the example tag can change over time.

## Optional local Kubernetes

Kubernetes is not needed for this small service. To learn its mechanics, install Docker, [kind](https://kind.sigs.k8s.io/docs/user/quick-start/) and [kubectl](https://kubernetes.io/docs/tasks/tools/) using their official OS instructions. `kind` creates a local cluster in Docker. Verify each command with `--version` (use `kubectl version --client`). Review available memory first. Then:

```text
kind create cluster --name academy
kind load docker-image gfa-lab:v1 --name academy
kubectl --context kind-academy apply -f kubernetes.yaml
kubectl --context kind-academy rollout status deployment/academy-lab --timeout=120s
kubectl --context kind-academy port-forward deployment/academy-lab 8765:8765
```

The explicit context prevents accidental deployment to another cluster. `apply` submits desired configuration. `rollout status` waits for readiness; `port-forward` exposes the local service while that command runs. Visit `/health`. If `ImagePullBackOff` appears, confirm the image was built and loaded into this named cluster. If a Pod restarts, inspect `kubectl --context kind-academy logs deployment/academy-lab`. Stop forwarding with Ctrl+C. After saving evidence, `kind delete cluster --name academy` removes this dedicated practice cluster and its data; do not use it for anything you need to retain.

## CI and infrastructure as code

The YAML manifest is declarative infrastructure configuration. The included GitHub workflow runs tests and evaluation when this lab folder is itself the repository root. If nested, set `defaults.run.working-directory` to its actual path. GitHub Actions runner usage may have plan limits; review account billing before enabling it. CI does not deploy cloud resources here. Serverless deployment would require choosing a provider runtime, entry point, secret configuration, limits and persistence; do not treat this long-running HTTP server as automatically compatible with every serverless host.

## Rollback rehearsal

1. Preserve a tested v1 folder or image and its commit ID. Save a passing health result and test report.
2. Make a separate v2 copy. Introduce a harmless failing health response there, or select failure in the browser simulator.
3. Run the v2 checks. Record that the release gate fails; do not promote it.
4. If rehearsing after a local launch, stop v2 with Ctrl+C and restart the preserved v1 folder or image.
5. Verify `/health`, a supported question, an unsupported question and the security tests. Record observed recovery time.
6. If data changed, test compatibility or restore using the supported database backup procedure. Application rollback alone does not revert data.

## Production boundary

Do not expose this teaching HTTP server to the public internet. A real deployment requires a production server, verified identity, TLS termination, secrets management, persistence, monitoring, quotas, vulnerability review and an accountable operator. Public cloud deployment is intentionally not executed or claimed by the kit. The course interface on GitHub Pages is static and separate from this Python service.
