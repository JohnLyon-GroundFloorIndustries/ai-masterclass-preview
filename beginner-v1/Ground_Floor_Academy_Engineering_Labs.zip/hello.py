"""First program: no accounts, packages or network required."""
name = "learner"  # A variable gives a value a name; this value is text.
tasks = ["Read policy", "Draft response"]  # A list holds multiple values.

def greeting(person):  # Define a reusable function accepting one input.
    return "Hello, " + person  # Return combined text to its caller.

print(greeting(name))  # Call the function, then display its returned text.
for number, task in enumerate(tasks, start=1):  # Repeat for each list item.
    print(number, task)  # Indented instructions belong to the loop.
if len(tasks) > 0:  # Test whether the list has at least one item.
    print("Ready:", len(tasks), "tasks")  # Count and display the items.
else:  # This branch runs when the condition above is false.
    print("No tasks yet")
