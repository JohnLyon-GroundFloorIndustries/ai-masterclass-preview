"""Loopback-only calculator API. Stop with Ctrl+C."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from tools import calculate

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            if self.path != "/calculate":
                self.send_error(404); return
            length = int(self.headers.get("Content-Length","0"))
            if not 1 <= length <= 4096:
                raise ValueError("Body must be 1 to 4096 bytes")
            data = json.loads(self.rfile.read(length))
            if not isinstance(data,dict) or set(data) != {"a","b"}:
                raise ValueError("Expected a and b")
            body = {"total":calculate(data["a"],data["b"])}
            code = 200
        except (ValueError,TypeError,UnicodeError) as error:
            body = {"error":str(error)}; code = 400
        raw = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(raw)))
        self.end_headers(); self.wfile.write(raw)

if __name__ == "__main__":
    print("Local calculator: http://127.0.0.1:8766/calculate — Ctrl+C to stop",flush=True)
    ThreadingHTTPServer(("127.0.0.1",8766),Handler).serve_forever()
