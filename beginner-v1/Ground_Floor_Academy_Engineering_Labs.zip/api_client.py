"""Run mock_api.py first in a separate terminal."""
import json  # Convert between Python values and JSON text.
from urllib.request import Request, urlopen  # Built-in HTTP client.
from urllib.error import URLError

body = json.dumps({"a":5,"b":7}).encode("utf-8")  # HTTP sends bytes.
request = Request("http://127.0.0.1:8766/calculate", data=body,
                  headers={"Content-Type":"application/json"}, method="POST")
try:
    with urlopen(request,timeout=3) as response:  # Wait at most 3 seconds.
        print("status", response.status)
        print("total", json.load(response)["total"])
except URLError:
    print("Cannot reach the local API. Run mock_api.py in another terminal first.")
    raise SystemExit(1)
