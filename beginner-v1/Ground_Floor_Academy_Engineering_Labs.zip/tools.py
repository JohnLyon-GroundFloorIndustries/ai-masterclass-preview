"""Validated local tools. No eval, shell execution or external accounts."""
import math
import re

DOCUMENTS = [
    {"id": "A-access-v1", "tenant": "alpha", "text": "For access recovery, ask the help desk to verify your identity before resetting access."},
    {"id": "A-review-v1", "tenant": "alpha", "text": "Support drafts require human review before any customer communication."},
    {"id": "B-private-v1", "tenant": "beta", "text": "Beta private support policy: contact the beta administrator for access recovery."},
]
REGISTRY = {
    "calculator": {"inputs": {"a": "number", "b": "number"}, "permission": "calculate"},
    "search": {"inputs": {"query": "string"}, "permission": "read_policy"},
    "create_task": {"inputs": {"title": "string"}, "permission": "draft_task"},
}

def calculate(a, b):
    for value in (a, b):
        if type(value) not in (int, float) or not math.isfinite(value) or abs(value) > 1_000_000:
            raise ValueError("a and b must be finite numbers between -1000000 and 1000000")
    return a + b

def search(query, tenant, documents=None):
    if not isinstance(query, str) or not 1 <= len(query.strip()) <= 2000:
        raise ValueError("query must contain 1 to 2000 characters")
    if tenant not in {"alpha", "beta"}:
        raise PermissionError("Unknown local identity fixture")
    # Filter BEFORE ranking or returning any document content.
    allowed = [d for d in (DOCUMENTS if documents is None else documents) if d["tenant"] == tenant]
    terms = set(re.findall(r"[a-z]+", query.lower())) - {"the", "a", "is", "how", "do", "i", "what", "to", "for", "my"}
    ranked = [(len(terms & set(re.findall(r"[a-z]+", d["text"].lower()))), d) for d in allowed]
    return [d for score, d in sorted(ranked, key=lambda item: (-item[0], item[1]["id"])) if score > 0][:2]

def invoke(name, arguments, permissions, tenant="alpha", store=None, key=None):
    if name not in REGISTRY:
        raise ValueError("Unknown tool")
    spec = REGISTRY[name]
    if spec["permission"] not in permissions:
        raise PermissionError("Tool permission denied")
    if not isinstance(arguments, dict) or set(arguments) != set(spec["inputs"]):
        raise ValueError("Unexpected or missing tool fields")
    if name == "calculator":
        return calculate(**arguments)
    if name == "search":
        return search(arguments["query"], tenant)
    if store is None or key is None:
        raise ValueError("Task writes require a store and operation key")
    return store.create(tenant, key, arguments["title"])
