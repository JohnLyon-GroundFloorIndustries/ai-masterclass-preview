"""Durable, tenant-scoped draft tasks with content-bound approval."""
import hashlib
import sqlite3
import time

def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

class Store:
    def __init__(self, path=":memory:"):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS tasks (
          id INTEGER PRIMARY KEY, tenant TEXT NOT NULL, op_key TEXT NOT NULL,
          original_hash TEXT NOT NULL, title TEXT NOT NULL, status TEXT NOT NULL,
          UNIQUE(tenant, op_key));
        CREATE TABLE IF NOT EXISTS approvals (
          task_id INTEGER PRIMARY KEY, content_hash TEXT NOT NULL, reviewer TEXT NOT NULL,
          expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS audit (
          id INTEGER PRIMARY KEY, event TEXT NOT NULL, task_id INTEGER, actor TEXT, at REAL NOT NULL);
        """)

    def close(self):
        self.db.close()

    def create(self, tenant, key, title):
        if tenant not in {"alpha", "beta"}:
            raise PermissionError("Unknown tenant")
        if not isinstance(key, str) or not 1 <= len(key) <= 100:
            raise ValueError("Operation key required, at most 100 characters")
        if not isinstance(title, str) or not 1 <= len(title.strip()) <= 4000:
            raise ValueError("Task title required, at most 4000 characters")
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            old = self.db.execute("SELECT * FROM tasks WHERE tenant=? AND op_key=?", (tenant, key)).fetchone()
            if old:
                if old["original_hash"] != digest(title):
                    raise ValueError("Operation key conflict: different original content")
                return dict(old)
            cursor = self.db.execute("INSERT INTO tasks(tenant,op_key,original_hash,title,status) VALUES(?,?,?,?,?)", (tenant,key,digest(title),title,"awaiting_review"))
            self._audit("created", cursor.lastrowid, tenant)
            return self.get(tenant, cursor.lastrowid)

    def get(self, tenant, task_id):
        row = self.db.execute("SELECT * FROM tasks WHERE tenant=? AND id=?", (tenant,task_id)).fetchone()
        if row is None:
            raise PermissionError("Task not accessible")
        return dict(row)

    def _audit(self, event, task_id, actor):
        self.db.execute("INSERT INTO audit(event,task_id,actor,at) VALUES(?,?,?,?)", (event,task_id,actor,time.time()))

    def revise(self, tenant, task_id, title):
        self.get(tenant, task_id)
        if not isinstance(title,str) or not 1 <= len(title.strip()) <= 4000:
            raise ValueError("Invalid revised title")
        with self.db:
            self.db.execute("UPDATE tasks SET title=?,status='awaiting_review' WHERE id=?", (title,task_id))
            self.db.execute("DELETE FROM approvals WHERE task_id=?", (task_id,))
            self._audit("revised_approval_invalidated",task_id,tenant)

    def approve(self, tenant, task_id, reviewer, ttl=300, expected_hash=None):
        # Local fixture only. A production service must obtain this role from real authentication.
        if reviewer != "local-reviewer":
            raise PermissionError("Local reviewer fixture required")
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            task = self.get(tenant,task_id)
            if expected_hash is not None and expected_hash != digest(task["title"]):
                raise PermissionError("Content changed since reviewer inspection")
            if task["status"] != "awaiting_review":
                raise ValueError("Task is not awaiting review")
            self.db.execute("INSERT OR REPLACE INTO approvals VALUES(?,?,?,?)", (task_id,digest(task["title"]),reviewer,time.time()+ttl))
            self._audit("approved",task_id,reviewer)

    def execute(self, tenant, task_id):
        # Atomic recheck and local state transition: no real messages are sent.
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            task = self.get(tenant,task_id)
            if task["status"] == "completed_local":
                return task
            row = self.db.execute("SELECT * FROM approvals WHERE task_id=?", (task_id,)).fetchone()
            if row is None or row["content_hash"] != digest(task["title"]) or row["expires"] <= time.time():
                raise PermissionError("Missing, changed or expired approval")
            self.db.execute("UPDATE tasks SET status='completed_local' WHERE id=?", (task_id,))
            self._audit("completed_local",task_id,row["reviewer"])
            return self.get(tenant,task_id)
