"""Two runnable architectures sharing the same deterministic worker roles.
This is an educational agent policy, not live model inference.
"""
import argparse
import json
import time
from pathlib import Path
from tools import search

def run(query="How do I reset access?", tenant="alpha", approach="sequential", fail_count=0, max_steps=8):
    if approach not in {"sequential","graph"}:
        raise ValueError("Unknown architecture")
    if type(max_steps) is not int or not 1 <= max_steps <= 20:
        raise ValueError("Step limit must be between 1 and 20")
    state = {"status":"received", "answer":"", "sources":[], "trace":[], "mode":"offline-deterministic", "tenant":tenant}
    steps = 0
    attempts = 0
    def emit(stage, status):
        state["trace"].append({"step":len(state["trace"])+1,"stage":stage,"status":status})
    def retrieve():
        nonlocal attempts
        attempts += 1
        if attempts <= fail_count:
            emit("researcher","transient_error")
            if attempts >= 3:
                state["status"] = "escalated"
                return "end"
            # Small demonstration backoff. Production needs jitter and a total deadline.
            time.sleep(0.001 * 2 ** (attempts-1))
            return "retrieve"
        docs = search(query,tenant)
        state["evidence"] = docs
        state["sources"] = [d["id"] for d in docs]
        state["status"] = "retrieved" if docs else "insufficient_evidence"
        emit("researcher",state["status"])
        return "draft" if docs else "end"
    def draft():
        # Extractive draft: no invented claims; a live model adapter is optional future work.
        state["answer"] = " ".join(d["text"] for d in state["evidence"])
        state["status"] = "drafted"
        emit("drafter","drafted")
        return "review"
    def review():
        permitted = all(d["tenant"] == tenant for d in state["evidence"])
        state["status"] = "awaiting_review" if permitted and state["sources"] else "escalated"
        emit("reviewer",state["status"])
        return "end"
    if approach == "graph":
        nodes = {"retrieve":retrieve,"draft":draft,"review":review}
        current = "retrieve"
        while current != "end" and steps < max_steps:
            steps += 1
            current = nodes[current]()
    else:
        current = "retrieve"
        while current == "retrieve" and steps < max_steps:
            steps += 1
            current = retrieve()
        if current == "draft" and steps < max_steps:
            steps += 1
            current = draft()
        if current == "review" and steps < max_steps:
            steps += 1
            current = review()
    if current != "end":
        state["status"] = "budget_exhausted"
        emit("controller","budget_exhausted")
    state.pop("evidence",None)
    return state

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--approach",choices=["sequential","graph"],default="sequential")
    parser.add_argument("--scenario",choices=["success","failure","unsupported","recovery"],default="success")
    args = parser.parse_args()
    result = run(query="What is the refund deadline?" if args.scenario == "unsupported" else "How do I reset access?", approach=args.approach, fail_count={"failure":9,"recovery":2}.get(args.scenario,0))
    Path("outputs").mkdir(exist_ok=True)
    Path("outputs/trace.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))
