# Ground Floor Academy engineering labs — Beginner v1.0

This is executable Python, separate from the educational simulations in the course HTML. The baseline is free, local, deterministic and uses fictional data. It performs real HTTP requests, retrieval, state transitions, SQLite writes, access checks, tests, load measurement and backup/restore. It does **not** run a neural model, send email, create cloud resources or establish production authentication.

## Start here: one small step at a time

1. Extract this ZIP. On Windows use right-click → Extract All; on macOS double-click; on Linux use your archive manager's Extract action. Open the extracted folder containing `hello.py`.
2. Follow `SETUP.md` for your operating system. It explains Python, terminals, folders and commands. Do not skip verification.
3. Run `python hello.py` (Windows) or `python3 hello.py` (macOS/Linux). Expect two task lines and `Ready: 2 tasks`.
4. Complete the lessons in order. Modules 0–2 require no installed tools. Module 3 begins real execution.

In all commands below, replace `python` with `python3` on macOS/Linux. Run commands from this extracted folder. No `pip install` is needed for the baseline. `requirements.txt` records this explicitly. Python 3.10 or later is required; the delivered baseline was tested on Python 3.10.6 on Windows.

## Lab sequence and evidence

| Module | Action | Expected evidence | Extension |
|---|---|---|---|
| 3 | `python hello.py` | Greeting, two numbered tasks, count 2 | Add a task; then try an empty list |
| 3 | `python mock_api.py`; second terminal: `python api_client.py` | HTTP status 200; total 12 | Change input values; reject a string |
| 4 | `python workflow.py --scenario success` | `awaiting_review`, source IDs, three role events | Set a smaller step limit in a copy |
| 5 | `python -m unittest tests.test_tools -v` | Calculator, schema, permission and tool tests pass | Add a disallowed tool request |
| 6 | `python workflow.py --scenario unsupported` | `insufficient_evidence`, empty sources | Add a fictional policy and test question |
| 7 | `python workflow.py --approach sequential` | Source-backed draft | Add a validation stage |
| 8 | Read the researcher/drafter/reviewer trace | Distinct role events, preserved provenance | Justify whether all three roles are needed |
| 9 | `python workflow.py --approach graph` | Same result as sequential; parity test passes | Add a graph branch with a test |
| 10 | Draw browser → application → tools → data | Every box has purpose, trust boundary and failure behavior | Add queue/cache only with justification |
| 11 | `python server.py` then open `http://127.0.0.1:8765` | A real local form produces a draft | Rehearse a version rollback |
| 12 | `python load_test.py` | `outputs/load.json`, 20 requests, 0 errors | Change concurrency and compare measured p95 |
| 12 | `python workflow.py --scenario recovery` | Two error events followed by recovery | Exceed three attempts and explain escalation |
| 13 | `python -m unittest tests.test_system.StorageTests -v` | Isolation, approval, expiration and idempotency tests | Add a new attack case before changing code |
| 14 | `python evaluate.py` | Four evaluated fixtures in `outputs/evaluation.json` | Add held-out questions and human rubric |
| 15 | `python recovery.py` | Restored true, integrity ok, measured time | Restore a larger fictional dataset |
| 16 | `python run_evidence.py` | `outputs/evidence.json` with passing tests, evaluation, load and recovery | Submit your changed version and rerun |

These worker roles use fixed code rather than autonomous LLMs. The graph and sequential approaches are two actual architectures; neither claims to be LangGraph or an MCP server. The course teaches those ecosystems and how to evaluate adoption. The baseline is intentionally inspectable before introducing provider dependencies.

## Understand the files

- `hello.py`: every meaningful line is commented for first-time programmers.
- `tools.py`: tool allowlist, schema checks, calculator and tenant-filtered lexical retrieval. It never evaluates arbitrary input as code.
- `workflow.py`: bounded controller and three roles; graph and sequential implementations share contracts.
- `storage.py`: SQLite tasks, immutable operation identity, approval binding and audit events.
- `server.py`: local web application. It accepts only a query, not a caller-supplied tenant. Identity is a fixed local fixture, not a real login.
- Successful server drafts are saved to `practice.db` and return a `task_id`. In another terminal run `python review_task.py 1`, replacing 1 with that returned ID. Inspect the exact draft and type APPROVE only if you accept it. This performs a local state transition and sends no message. The optional `request_id` API field deduplicates repeated requests.
- `optional_model.py`: optional, explicitly authorized paid inference with filtered fictional evidence; see `OPTIONAL_MODEL.md`. Tested with a fake transport, not a live account.
- `tests/`: executable behavior checks. Read test names as statements of intended behavior.
- `evaluate.py`: transparent quality fixtures. Tiny sample coverage is not a real-world accuracy claim.
- `load_test.py`: starts a temporary local server, sends actual concurrent requests, stops it and reports measured latency.
- `recovery.py`: creates and restores a consistent SQLite backup in a temporary folder.
- `run_evidence.py`: runs checks and generates a portable report with source hashes.
- `Dockerfile`, `kubernetes.yaml`, `.github/workflows/tests.yml`: optional packaging and automation configurations; see `DEPLOYMENT.md` for prerequisites and verification boundaries.

## Hands-on approval walkthrough

Create a file named `approval_demo.py` beside `storage.py`, containing the following complete program. Do not paste these lines into PowerShell individually; they are Python source.

```python
from storage import Store  # Import our saved-record implementation.
store = Store("practice.db")  # Open a local file; create tables if needed.
task = store.create("alpha", "practice-1", "Draft a support reply")  # Save once.
print(task["status"])  # Expected: awaiting_review.
store.approve("alpha", task["id"], "local-reviewer")  # Local identity fixture only.
print(store.execute("alpha", task["id"])["status"])  # Expected: completed_local.
store.close()  # Close the database connection.
```

Run `python approval_demo.py`. No communication is sent: “execute” changes only the local training record. Run again: the saved completed task is returned, but approving it again raises `Task is not awaiting review`. This is deliberate state enforcement. For another exercise use a new operation key such as `practice-2`. Try removing the approval call on a new task: execution must raise `PermissionError`. Try revising a newly approved task before execution: the approval must be invalidated. Do not catch and ignore a permission error to force the operation.

## Capstone: 14 evidence gates

1. State the fictional support problem, users and acceptance criteria in `CAPSTONE.md`.
2. State non-goals: no sending messages, no autonomous promises, no real private data.
3. Explain researcher, drafter and reviewer roles and whether separation improves your case.
4. Select the offline policy first; document model/tool alternatives and their evidence requirements.
5. Run the first supported question and retain the result.
6. Add a document with owner/source/version and prove retrieval finds it only for its tenant.
7. Compare one controller with multiple roles; record quality and complexity tradeoffs.
8. Demonstrate a forbidden tenant read and unknown tool request being denied.
9. Demonstrate valid, missing, expired and changed-content approvals.
10. Demonstrate duplicate delivery, temporary failure, exhausted retries and restart.
11. Run the local web application from a clean extracted folder. Optional container/cloud deployment must be separately recorded.
12. Measure local load; calculate a hypothetical model budget and enforce a step limit.
13. Write architecture decisions, field ownership, privacy inventory, setup and runbook.
14. Attach tests, evaluation, source hashes, trace, restore and rollback evidence; list residual risks and obtain independent review.

Score each gate: 0 absent; 1 explained; 2 executed with reproducible evidence; 3 independently reproduced and challenged. A lesson checkmark does not increase this score. An imported evidence JSON is learner-supplied and editable, not a signed certification. Production use additionally requires real identity, security assessment, operational ownership, representative data evaluations, capacity planning and applicable governance.

## Incident runbook

1. Confirm impact with one synthetic question. Record the time and version.
2. Stop consequential actions; the baseline already creates drafts only.
3. Read the first failing stage in `outputs/trace.json` without copying private payloads.
4. If retrieval fails, verify tenant and query validity before retrying. If evidence is absent, refuse unsupported claims.
5. If a write has unknown outcome, look up the operation key before retrying.
6. Restore the known working version using `DEPLOYMENT.md`; restore data separately if needed.
7. Run tests and a representative request. Monitor before declaring recovery.
8. Record cause, contributing factors and a regression test. Do not label a restart itself as proof of recovery.

## Limits you must preserve in a handoff

The server is a loopback teaching server using Python's HTTP library. It is not hardened internet hosting. Local reviewer identity is simulated. Audit rows are not tamper-proof. Retrieval is lexical, not embeddings. Role decisions are deterministic, not live inference. One-machine measurements do not establish cloud scale. Docker, Kubernetes, Linux/macOS execution and cloud deployment require separate evidence on those environments. No optional service should be created merely to claim completion.
