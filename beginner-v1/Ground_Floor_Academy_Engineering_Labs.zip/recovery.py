"""Consistent SQLite backup and restore drill in a temporary directory."""
import json
import sqlite3
import tempfile
import time
from pathlib import Path
from storage import Store

def drill():
    with tempfile.TemporaryDirectory() as folder:
        source=Store(str(Path(folder)/"source.db"))
        task=source.create("alpha","recovery-1","Draft awaiting review")
        backup=sqlite3.connect(str(Path(folder)/"backup.db"))
        source.db.backup(backup); source.close()
        start=time.perf_counter()
        restored=sqlite3.connect(str(Path(folder)/"restored.db"))
        backup.backup(restored); restored.close(); backup.close()
        check=Store(str(Path(folder)/"restored.db"))
        recovered=check.get("alpha",task["id"])
        integrity=check.db.execute("PRAGMA integrity_check").fetchone()[0]
        check.close()
        return {"restored":recovered["title"]==task["title"],"integrity":integrity,"restore_seconds":round(time.perf_counter()-start,6),"scope":"one local SQLite fixture; not a disaster-recovery guarantee"}
if __name__ == "__main__":
    result=drill(); Path("outputs").mkdir(exist_ok=True)
    Path("outputs/recovery.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))
