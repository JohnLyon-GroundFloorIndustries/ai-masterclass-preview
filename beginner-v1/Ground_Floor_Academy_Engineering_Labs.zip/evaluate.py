"""Transparent quality fixtures: a small baseline, not broad assurance."""
import json
from pathlib import Path
from workflow import run

CASES = [
    ("How do I reset access?","alpha","awaiting_review","A-access-v1"),
    ("human review","alpha","awaiting_review","A-review-v1"),
    ("refund deadline","alpha","insufficient_evidence",None),
    ("access recovery","beta","awaiting_review","B-private-v1"),
]
def evaluate():
    rows=[]
    for query,tenant,status,source in CASES:
        result=run(query,tenant)
        passed=result["status"]==status and (source is None or source in result["sources"])
        rows.append({"query":query,"tenant":tenant,"passed":passed,"status":result["status"]})
    return rows
if __name__ == "__main__":
    rows=evaluate(); Path("outputs").mkdir(exist_ok=True)
    Path("outputs/evaluation.json").write_text(json.dumps(rows,indent=2),encoding="utf-8")
    print(json.dumps(rows,indent=2))
    raise SystemExit(0 if all(r["passed"] for r in rows) else 1)
