"""Runnable local support-draft web application. Not an internet-ready server."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import argparse
import json
import uuid
from workflow import run
from storage import Store

DB_PATH = "practice.db"

PAGE = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Academy local lab</title>
<style>body{font:18px system-ui;max-width:760px;margin:40px auto;padding:20px;background:#f4f1e8;color:#2b2b2b}input,button{font:inherit;padding:12px}input{width:90%}pre{white-space:pre-wrap;overflow-wrap:anywhere}button{margin-top:16px;background:#1f5c5b;color:white;border:0}</style>
<h1>Support-draft lab</h1><p>Real local Python execution. Deterministic retrieval and worker roles; no live AI or external messages. Local identity fixture: alpha.</p>
<form id="form"><label for="query">Fictional support question</label><input id="query" value="How do I reset access?" maxlength="2000" required><button>Build draft</button></form><pre id="result" aria-live="polite"></pre>
<script>document.querySelector('#form').onsubmit=async e=>{e.preventDefault();const out=document.querySelector('#result');try{const r=await fetch('/draft',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:document.querySelector('#query').value})});out.textContent=JSON.stringify(await r.json(),null,2)}catch(e){out.textContent='Cannot reach the local server. Check its terminal.'}};</script></html>'''

class Handler(BaseHTTPRequestHandler):
    def reply(self, code, value, content_type="application/json"):
        raw = (json.dumps(value) if content_type == "application/json" else value).encode()
        self.send_response(code)
        self.send_header("Content-Type",content_type+"; charset=utf-8")
        self.send_header("Content-Length",str(len(raw)))
        self.send_header("X-Content-Type-Options","nosniff")
        self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        if self.path == "/health": self.reply(200,{"status":"ok","mode":"offline-deterministic"})
        elif self.path == "/": self.reply(200,PAGE,"text/html")
        else: self.reply(404,{"error":"Not found"})
    def do_POST(self):
        if self.path != "/draft": self.reply(404,{"error":"Not found"}); return
        # Reject browser cross-origin submissions; no CORS permissions are granted.
        origin = self.headers.get("Origin")
        if origin and origin not in {"http://127.0.0.1:8765","http://localhost:8765"}:
            self.reply(403,{"error":"Cross-origin request denied"}); return
        try:
            size = int(self.headers.get("Content-Length","0"))
            if not 1 <= size <= 4096: raise ValueError("Request size invalid")
            body = json.loads(self.rfile.read(size))
            if not isinstance(body,dict) or "query" not in body or set(body)-{"query","request_id"}: raise ValueError("Only query and optional request_id are accepted; identity cannot be supplied")
            result = run(body["query"],tenant="alpha")
            if result["status"] == "awaiting_review":
                key=body.get("request_id",str(uuid.uuid4()))
                store=Store(DB_PATH)
                try:
                    task=store.create("alpha",key,result["answer"])
                    result.update(task_id=task["id"],operation_key=key)
                finally:
                    store.close()
            self.reply(200,result)
        except (ValueError,TypeError,UnicodeError) as error:
            self.reply(400,{"error":str(error)})

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--container",action="store_true",help="Bind inside a container; publish only to host loopback")
    args = parser.parse_args()
    host = "0.0.0.0" if args.container else "127.0.0.1"
    print("Training service: http://127.0.0.1:8765 — Ctrl+C to stop",flush=True)
    ThreadingHTTPServer((host,8765),Handler).serve_forever()
