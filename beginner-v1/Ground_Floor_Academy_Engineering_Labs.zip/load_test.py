"""Small real HTTP load measurement; starts and stops its own local server."""
import concurrent.futures
import json
import threading
import time
import tempfile
import server
from pathlib import Path
from urllib.request import Request,urlopen
from http.server import ThreadingHTTPServer
from server import Handler

def measure():
    temporary=tempfile.TemporaryDirectory()
    old_path=server.DB_PATH
    server.DB_PATH=str(Path(temporary.name)/"load.db")
    service=ThreadingHTTPServer(("127.0.0.1",0),Handler)
    thread=threading.Thread(target=service.serve_forever,daemon=True); thread.start()
    def request(_):
        start=time.perf_counter()
        try:
            req=Request(f"http://127.0.0.1:{service.server_port}/draft",data=json.dumps({"query":"reset access"}).encode(),headers={"Content-Type":"application/json"})
            with urlopen(req,timeout=5) as response:
                ok=json.load(response)["status"]=="awaiting_review"
            return (time.perf_counter()-start)*1000,ok
        except Exception:
            return (time.perf_counter()-start)*1000,False
    start=time.perf_counter()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            rows=list(pool.map(request,range(20)))
        elapsed=time.perf_counter()-start
    finally:
        service.shutdown(); service.server_close(); thread.join()
        server.DB_PATH=old_path; temporary.cleanup()
    times=sorted(r[0] for r in rows)
    return {"requests":20,"concurrency":4,"errors":sum(not r[1] for r in rows),"p95_ms":round(times[18],2),"throughput_per_second":round(20/elapsed,2),"scope":"local deterministic service only"}
if __name__ == "__main__":
    result=measure(); Path("outputs").mkdir(exist_ok=True)
    Path("outputs/load.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))
    raise SystemExit(0 if result["errors"]==0 else 1)
