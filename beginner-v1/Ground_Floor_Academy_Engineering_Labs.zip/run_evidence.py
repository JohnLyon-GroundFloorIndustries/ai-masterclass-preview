"""Run the real checks and write a portable, learner-supplied evidence report."""
import hashlib
import json
import platform
import unittest
from datetime import datetime,timezone
from pathlib import Path
from evaluate import evaluate
from recovery import drill
from load_test import measure

suite=unittest.defaultTestLoader.discover("tests")
result=unittest.TextTestRunner(verbosity=2).run(suite)
evaluation=evaluate(); recovery=drill(); load=measure()
passed=result.wasSuccessful() and all(r["passed"] for r in evaluation) and recovery["restored"] and load["errors"]==0
report={"schema":"gfa-lab-evidence-v1","release":"beginner-v1","generated":datetime.now(timezone.utc).isoformat(),"python":platform.python_version(),"tests":result.testsRun,"failures":len(result.failures)+len(result.errors),"passed":passed,"evaluation":evaluation,"recovery":recovery,"load":load,"source_hashes":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('.').glob('*.py')},"scope":"Offline deterministic training service. No live model, cloud, container or independent security certification."}
Path("outputs").mkdir(exist_ok=True)
Path("outputs/evidence.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
print("Evidence written to outputs/evidence.json; passed =",passed)
raise SystemExit(0 if passed else 1)
