"""Local human approval exercise for a task created by server.py."""
import argparse
from storage import Store,digest

parser=argparse.ArgumentParser(description="Inspect and approve one local draft; never sends a message")
parser.add_argument("task_id",type=int)
args=parser.parse_args()
store=Store("practice.db")
try:
    task=store.get("alpha",args.task_id)
    print("Exact proposed local task:\n",task["title"])
    print("Status:",task["status"])
    if task["status"] == "completed_local":
        print("Already completed locally; no new action.")
    elif input("Type APPROVE to approve this exact text, or anything else to leave it pending: ") == "APPROVE":
        store.approve("alpha",args.task_id,"local-reviewer",expected_hash=digest(task["title"]))
        print(store.execute("alpha",args.task_id)["status"])
    else:
        print("Left pending. No permission granted.")
finally:
    store.close()
