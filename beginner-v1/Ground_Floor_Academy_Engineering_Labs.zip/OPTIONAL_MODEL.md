# Optional live model extension — potentially paid, separate from the baseline

Do this only after the offline capstone tests pass. The included `optional_model.py` sends one fictional question and already permission-filtered fictional evidence to the OpenAI Responses API. It drafts text, exposes usage and labels the result unverified. It never receives task-write tools or sends customer messages. This extension is source-complete and tested with a fake transport; **live provider execution is not claimed**.

## Before choosing to make a call

1. Read current [text-generation documentation](https://developers.openai.com/api/docs/guides/text), model availability, pricing and data-handling terms for your account. A ChatGPT product subscription is not blanket authorization for API charges.
2. Choose a supported model identifier and verify that it supports the request parameters. The course deliberately does not hard-code a model that may become unavailable.
3. Review the source. It sends only fictional course evidence, sets `store` false and caps output at 400 tokens. That setting is not a claim of zero provider retention; inspect current provider policy. One call can still cost money, including one that times out. There is no automatic retry.
4. Set appropriate provider limits. The sample limits calls and output tokens; it is not a guaranteed dollar-denominated spending cap. Estimate worst-case input/output cost for your selected model before proceeding.
5. Obtain a restricted API key through your account’s official interface. Never put it in the browser HTML, source files, screenshots, Git, or chat. An environment variable is a named value passed to a process. If `OPENAI_API_KEY` is already securely configured, the script uses it. Otherwise the script prompts with hidden input and retains the key only in process memory.

## Execute one optional call

In the lab folder run the following, replacing the model label with the exact identifier you selected:

```text
python optional_model.py --model YOUR_SELECTED_MODEL --allow-paid-call
```

Use `python3` on macOS/Linux. `--model` supplies the model name. `--allow-paid-call` is explicit consent in your local command to send the single request. No additional packages are required. Expect `status: unverified_model_draft`, answer text, evidence IDs and provider usage. The exact answer varies. Check every sentence against `A-access-v1`; do not treat the listed source IDs as proof that the answer uses them correctly.

For a 401 error, verify the credential without printing it. For an unavailable model, check account access and official identifiers. For a 429 or timeout, inspect provider usage and limits before deciding whether to make another paid request. Do not add unbounded retries. For incomplete or empty output, retain the explicit failure; do not label it a successful draft.

## Extend carefully

Inject this adapter only at the draft stage of the existing controller. Keep retrieval filtering, tool allowlists, validation, budgets and human approval outside the model. Compare it with the extractive baseline using a larger held-out evaluation set and human rubric. If you add tool calling, validate every proposed tool name and argument with `tools.invoke`; never execute arbitrary generated code. Record model ID, request settings, usage, quality results and the tested source revision. This exercise does not verify multi-agent cloud operations or production readiness.
