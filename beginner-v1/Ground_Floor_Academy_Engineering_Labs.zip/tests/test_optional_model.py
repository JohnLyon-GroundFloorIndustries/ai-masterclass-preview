import io
import json
import unittest
from optional_model import model_draft

class ModelAdapterTests(unittest.TestCase):
    def test_transport_contract(self):
        captured={}
        def fake(request,timeout):
            captured.update(json.loads(request.data))
            self.assertEqual(timeout,30)
            self.assertEqual(request.full_url,"https://api.openai.com/v1/responses")
            return io.StringIO(json.dumps({"status":"completed","output":[{"type":"message","content":[{"type":"output_text","text":"Ask the help desk [A-access-v1]."}]}],"usage":{"input_tokens":20,"output_tokens":12}}))
        result=model_draft("reset access","alpha","test-model","not-a-real-key",opener=fake)
        self.assertEqual(result["status"],"unverified_model_draft")
        self.assertFalse(captured["store"])
        self.assertEqual(captured["max_output_tokens"],400)
        self.assertNotIn("B-private",captured["input"])
    def test_no_evidence_no_call(self):
        def fail(*args,**kwargs): raise AssertionError("Network must not run")
        self.assertEqual(model_draft("refund deadline","alpha","x","x",fail)["status"],"insufficient_evidence")
    def test_incomplete_rejected(self):
        def fake(*args,**kwargs): return io.StringIO('{"status":"incomplete"}')
        with self.assertRaises(ValueError): model_draft("access","alpha","x","x",fake)
