import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from http.server import ThreadingHTTPServer
from storage import Store,digest
from workflow import run
from server import Handler
import server
from evaluate import evaluate
from recovery import drill

class StorageTests(unittest.TestCase):
    def setUp(self): self.store=Store()
    def tearDown(self): self.store.close()
    def task(self): return self.store.create("alpha","key-1","Draft one")
    def test_duplicate(self): self.assertEqual(self.task()["id"],self.task()["id"])
    def test_key_conflict(self):
        self.task()
        with self.assertRaises(ValueError): self.store.create("alpha","key-1","Other")
    def test_cross_tenant(self):
        task=self.task()
        with self.assertRaises(PermissionError): self.store.get("beta",task["id"])
    def test_unapproved(self):
        with self.assertRaises(PermissionError): self.store.execute("alpha",self.task()["id"])
    def test_approved(self):
        task=self.task(); self.store.approve("alpha",task["id"],"local-reviewer")
        self.assertEqual(self.store.execute("alpha",task["id"])["status"],"completed_local")
    def test_revision_invalidates(self):
        task=self.task(); self.store.approve("alpha",task["id"],"local-reviewer")
        self.store.revise("alpha",task["id"],"Changed")
        with self.assertRaises(PermissionError): self.store.execute("alpha",task["id"])
    def test_expired(self):
        task=self.task(); self.store.approve("alpha",task["id"],"local-reviewer",ttl=-1)
        with self.assertRaises(PermissionError): self.store.execute("alpha",task["id"])
    def test_bad_reviewer(self):
        with self.assertRaises(PermissionError): self.store.approve("alpha",self.task()["id"],"model")
    def test_changed_since_inspection(self):
        task=self.task()
        self.store.revise("alpha",task["id"],"Changed after inspection")
        with self.assertRaises(PermissionError): self.store.approve("alpha",task["id"],"local-reviewer",expected_hash=digest(task["title"]))
    def test_audit(self):
        self.task(); self.assertEqual(self.store.db.execute("SELECT event FROM audit").fetchone()[0],"created")
    def test_restart(self):
        with tempfile.TemporaryDirectory() as folder:
            path=str(Path(folder)/"state.db"); one=Store(path); task=one.create("alpha","x","Persist"); one.close()
            two=Store(path)
            self.assertEqual(two.create("alpha","x","Persist")["id"],task["id"])
            two.close()

class WorkflowTests(unittest.TestCase):
    def test_success(self): self.assertEqual(run()["status"],"awaiting_review")
    def test_parity(self): self.assertEqual(run(),run(approach="graph"))
    def test_failure(self): self.assertEqual(run(fail_count=9)["status"],"escalated")
    def test_recovery(self): self.assertEqual(run(fail_count=2)["status"],"awaiting_review")
    def test_budget(self): self.assertEqual(run(max_steps=1)["status"],"budget_exhausted")
    def test_evaluations(self): self.assertTrue(all(r["passed"] for r in evaluate()))
    def test_restore(self): self.assertTrue(drill()["restored"])

class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.old_path=server.DB_PATH
        server.DB_PATH=str(Path(cls.temp.name)/"http.db")
        cls.service=ThreadingHTTPServer(("127.0.0.1",0),Handler)
        cls.thread=threading.Thread(target=cls.service.serve_forever,daemon=True); cls.thread.start()
        cls.base=f"http://127.0.0.1:{cls.service.server_port}"
    @classmethod
    def tearDownClass(cls):
        cls.service.shutdown(); cls.service.server_close(); cls.thread.join()
        server.DB_PATH=cls.old_path; cls.temp.cleanup()
    def post(self,body,headers=None):
        return urlopen(Request(self.base+"/draft",data=json.dumps(body).encode(),headers=headers or {"Content-Type":"application/json"}),timeout=3)
    def test_health(self):
        with urlopen(self.base+"/health") as response: self.assertEqual(json.load(response)["status"],"ok")
    def test_draft(self):
        with self.post({"query":"reset access"}) as response: self.assertEqual(json.load(response)["status"],"awaiting_review")
    def test_identity_cannot_be_supplied(self):
        with self.assertRaises(HTTPError) as error: self.post({"query":"access","tenant":"beta"})
        self.assertEqual(error.exception.code,400)
    def test_http_idempotency(self):
        with self.post({"query":"reset access","request_id":"same-request"}) as response: first=json.load(response)
        with self.post({"query":"reset access","request_id":"same-request"}) as response: second=json.load(response)
        self.assertEqual(first["task_id"],second["task_id"])
    def test_cross_origin(self):
        with self.assertRaises(HTTPError) as error: self.post({"query":"access"},{"Origin":"https://untrusted.example"})
        self.assertEqual(error.exception.code,403)
